Rollerball-Midterm


The two tweaks that I want to highlight that I added from the discussion post were color specific levels, and the dash function.

Color-specific levels:
In the game I have three different stages, the default stage, the blue stage, and the red stage. The player must collect the corresponding color pickup item to change their color and unlock the stage. 
For example, picking up the blue color pickup will change the color blue and moving to the blue wall will unlock the blue stage. The same for the red color pickup, it will change the player red, and unlock the red stage.

Dash:
The dash function was added to help the player get to speed faster. Pressing the spacebar will make the player roll faster for a short amount of time. If the player is moving at max speed, the dash function will not work. This is to prevent game-breaking bugs.

Other:
Since it is still possible for a player to work their way off the map, I included a collider to return them back onto the map rather than end the game.